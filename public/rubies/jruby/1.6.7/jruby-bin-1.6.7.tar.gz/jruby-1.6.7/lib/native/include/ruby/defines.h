// Stub file provided for C extensions that expect it.
