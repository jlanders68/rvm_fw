require 'mkmf'
create_makefile("-test-/funcall/funcall")
