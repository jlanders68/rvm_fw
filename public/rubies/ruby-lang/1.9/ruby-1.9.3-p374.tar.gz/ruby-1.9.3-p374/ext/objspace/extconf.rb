$INCFLAGS << " -I$(topdir) -I$(top_srcdir)"
create_makefile('objspace')
